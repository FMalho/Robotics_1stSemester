#include <rclcpp/rclcpp.hpp>
#include <moveit/planning_scene/planning_scene.h>
#include <moveit/planning_scene_interface/planning_scene_interface.h>
#include <moveit/task_constructor/task.h>
#include <moveit/task_constructor/solvers.h>
#include <moveit/task_constructor/stages.h>
#include <geometry_msgs/msg/pose.hpp>
#include <moveit_msgs/msg/collision_object.hpp>
#include <shape_msgs/msg/solid_primitive.hpp>
#include <tf2_geometry_msgs/tf2_geometry_msgs.hpp>
#include <tf2_eigen/tf2_eigen.hpp>

static const rclcpp::Logger LOGGER = rclcpp::get_logger("mtc_tutorial");
namespace mtc = moveit::task_constructor;

class MTCTaskNode
{
public:
  MTCTaskNode(const rclcpp::NodeOptions& options);
  rclcpp::node_interfaces::NodeBaseInterface::SharedPtr getNodeBaseInterface();
  void doTask();
  void setupPlanningScene();

private:
  mtc::Task createTask();
  mtc::Task task_;
  rclcpp::Node::SharedPtr node_;
};

MTCTaskNode::MTCTaskNode(const rclcpp::NodeOptions& options)
  : node_{ std::make_shared<rclcpp::Node>("mtc_node", options) }
{
}

rclcpp::node_interfaces::NodeBaseInterface::SharedPtr MTCTaskNode::getNodeBaseInterface()
{
  return node_->get_node_base_interface();
}

void MTCTaskNode::setupPlanningScene()
{
  moveit::planning_interface::PlanningSceneInterface psi;

  // --- CILINDRO 1 (VERDE) ---
  moveit_msgs::msg::CollisionObject c1;
  c1.id = "cylinder_1";
  c1.header.frame_id = "world";
  c1.primitives.resize(1);
  c1.primitives[0].type = shape_msgs::msg::SolidPrimitive::CYLINDER;
  c1.primitives[0].dimensions = { 0.1, 0.02 }; 
  c1.pose.position.x = 0.5;
  c1.pose.position.y = -0.25;
  c1.pose.position.z = 0.05;  
  c1.pose.orientation.w = 1.0;

  moveit_msgs::msg::ObjectColor color1;
  color1.id = "cylinder_1";
  color1.color.r = 0.0; color1.color.g = 1.0; color1.color.b = 0.0; color1.color.a = 1.0;

  psi.applyCollisionObject(c1, color1.color);
}

void MTCTaskNode::doTask()
{
  task_ = createTask();
  try {
    task_.init();
  } catch (mtc::InitStageException& e) {
    RCLCPP_ERROR_STREAM(LOGGER, e);
    return;
  }

  if (!task_.plan(5)) {
    RCLCPP_ERROR_STREAM(LOGGER, "Task planning failed");
    return;
  }
  task_.introspection().publishSolution(*task_.solutions().front());
  auto result = task_.execute(*task_.solutions().front());
  
  if (result.val != moveit_msgs::msg::MoveItErrorCodes::SUCCESS) {
    RCLCPP_ERROR_STREAM(LOGGER, "Task execution failed");
  }
}

mtc::Task MTCTaskNode::createTask()
{
  mtc::Task task;
  task.stages()->setName("Pick Place Demo");
  task.loadRobotModel(node_);

  const auto& arm_group_name = "panda_arm";
  const auto& hand_group_name = "hand";
  const auto& hand_frame = "panda_hand";

  task.setProperty("group", arm_group_name);
  task.setProperty("eef", hand_group_name);
  task.setProperty("ik_frame", hand_frame);

  auto sampling_planner = std::make_shared<mtc::solvers::PipelinePlanner>(node_, "ompl");
  auto interpolation_planner = std::make_shared<mtc::solvers::JointInterpolationPlanner>();
  auto cartesian_planner = std::make_shared<mtc::solvers::CartesianPath>();
  cartesian_planner->setMaxVelocityScalingFactor(1.0);
  cartesian_planner->setMaxAccelerationScalingFactor(1.0);
  cartesian_planner->setStepSize(.01);

  mtc::Stage* current_state_ptr = nullptr;
  mtc::Stage* attach_stage_c1 = nullptr;

  // --- POSIÇÕES ---
  geometry_msgs::msg::Pose pose_buffer;
  pose_buffer.position.x = 0.4; 
  pose_buffer.position.y = 0.6; 
  pose_buffer.position.z = 0.05;
  pose_buffer.orientation.w = 1.0;

  // 1. ESTADO INICIAL 
  {
      auto stage_state_current = std::make_unique<mtc::stages::CurrentState>("current");
      current_state_ptr = stage_state_current.get();
      task.add(std::move(stage_state_current));

      {
          auto stage = std::make_unique<mtc::stages::ModifyPlanningScene>("ignore robot self-collisions");
          const auto& arm_links = task.getRobotModel()->getJointModelGroup(arm_group_name)->getLinkModelNamesWithCollisionGeometry();
          for(const auto& link : arm_links) { stage->allowCollisions(link, true); }
          const auto& hand_links = task.getRobotModel()->getJointModelGroup(hand_group_name)->getLinkModelNamesWithCollisionGeometry();
          for(const auto& link : hand_links) { stage->allowCollisions(link, true); }
          stage->allowCollisions("cylinder_1", true);
          task.add(std::move(stage));
      }

      auto stage_open_hand = std::make_unique<mtc::stages::MoveTo>("open hand", interpolation_planner);
      stage_open_hand->setGroup(hand_group_name);
      stage_open_hand->setGoal("open");
      task.add(std::move(stage_open_hand));

      auto stage_ready = std::make_unique<mtc::stages::MoveTo>("move to ready", sampling_planner);
      stage_ready->setGroup(arm_group_name);
      stage_ready->setGoal("ready");
      task.add(std::move(stage_ready));

      {
          auto stage = std::make_unique<mtc::stages::ModifyPlanningScene>("re-enable object collisions");
          stage->allowCollisions("cylinder_1", false);
          task.add(std::move(stage));
      }
  }

  // 2. PICK CILINDRO 1
  {
      auto stage_connect = std::make_unique<mtc::stages::Connect>(
          "move to pick C1", mtc::stages::Connect::GroupPlannerVector{ { arm_group_name, sampling_planner } });
      stage_connect->setTimeout(5.0);
      stage_connect->properties().configureInitFrom(mtc::Stage::PARENT);
      task.add(std::move(stage_connect));

      auto grasp = std::make_unique<mtc::SerialContainer>("pick C1");
      task.properties().exposeTo(grasp->properties(), { "eef", "group", "ik_frame" });
      grasp->properties().configureInitFrom(mtc::Stage::PARENT, { "eef", "group", "ik_frame" });

      {
          auto stage = std::make_unique<mtc::stages::MoveRelative>("approach C1", cartesian_planner);
          stage->properties().set("marker_ns", "approach_c1");
          stage->properties().set("link", hand_frame);
          stage->properties().configureInitFrom(mtc::Stage::PARENT, { "group" });
          stage->setMinMaxDistance(0.1, 0.15);
          geometry_msgs::msg::Vector3Stamped vec;
          vec.header.frame_id = hand_frame;
          vec.vector.z = 1.0;
          stage->setDirection(vec);
          grasp->insert(std::move(stage));
      }
      {
          auto stage = std::make_unique<mtc::stages::GenerateGraspPose>("gen grasp C1");
          stage->properties().configureInitFrom(mtc::Stage::PARENT);
          stage->setPreGraspPose("open");
          stage->setObject("cylinder_1");
          stage->setAngleDelta(M_PI / 12);
          stage->setMonitoredStage(current_state_ptr);

          Eigen::Isometry3d grasp_frame_transform;
          Eigen::Quaterniond q = Eigen::AngleAxisd(M_PI / 2, Eigen::Vector3d::UnitX()) *
                                 Eigen::AngleAxisd(M_PI / 2, Eigen::Vector3d::UnitY()) *
                                 Eigen::AngleAxisd(M_PI / 2, Eigen::Vector3d::UnitZ());
          grasp_frame_transform.linear() = q.matrix();
          grasp_frame_transform.translation().z() = 0.1;

          auto wrapper = std::make_unique<mtc::stages::ComputeIK>("grasp IK C1", std::move(stage));
          wrapper->setMaxIKSolutions(8);
          wrapper->setMinSolutionDistance(1.0);
          wrapper->setIKFrame(grasp_frame_transform, hand_frame);
          wrapper->properties().configureInitFrom(mtc::Stage::PARENT, { "eef", "group" });
          wrapper->properties().configureInitFrom(mtc::Stage::INTERFACE, { "target_pose" });
          grasp->insert(std::move(wrapper));
      }
      {
          auto stage = std::make_unique<mtc::stages::ModifyPlanningScene>("allow C1 collision");
          stage->allowCollisions("cylinder_1", task.getRobotModel()->getJointModelGroup(hand_group_name)->getLinkModelNamesWithCollisionGeometry(), true);
          grasp->insert(std::move(stage));
      }
      {
          auto stage = std::make_unique<mtc::stages::MoveTo>("close hand", interpolation_planner);
          stage->setGroup(hand_group_name);
          stage->setGoal("close");
          grasp->insert(std::move(stage));
      }
      {
          auto stage = std::make_unique<mtc::stages::ModifyPlanningScene>("attach C1");
          stage->attachObject("cylinder_1", hand_frame);
          attach_stage_c1 = stage.get();
          grasp->insert(std::move(stage));
      }
      {
          auto stage = std::make_unique<mtc::stages::MoveRelative>("lift C1", cartesian_planner);
          stage->properties().configureInitFrom(mtc::Stage::PARENT, { "group" });
          stage->setMinMaxDistance(0.1, 0.3);
          stage->setIKFrame(hand_frame);
          geometry_msgs::msg::Vector3Stamped vec;
          vec.header.frame_id = "world";
          vec.vector.z = 1.0;
          stage->setDirection(vec);
          grasp->insert(std::move(stage));
      }
      task.add(std::move(grasp));
  }

  // 3. PLACE CILINDRO 1 
  {
      auto stage_connect = std::make_unique<mtc::stages::Connect>(
          "move to buffer", mtc::stages::Connect::GroupPlannerVector{ { arm_group_name, sampling_planner } });
      stage_connect->setTimeout(5.0);
      stage_connect->properties().configureInitFrom(mtc::Stage::PARENT);
      task.add(std::move(stage_connect));

      auto place = std::make_unique<mtc::SerialContainer>("place C1 at Buffer");
      task.properties().exposeTo(place->properties(), { "eef", "group", "ik_frame" });
      place->properties().configureInitFrom(mtc::Stage::PARENT, { "eef", "group", "ik_frame" });

      {
          auto stage = std::make_unique<mtc::stages::GeneratePlacePose>("gen place buffer");
          stage->properties().configureInitFrom(mtc::Stage::PARENT);
          stage->setObject("cylinder_1");
          geometry_msgs::msg::PoseStamped target_pose_msg;
          target_pose_msg.header.frame_id = "world";
          target_pose_msg.pose = pose_buffer;
          stage->setPose(target_pose_msg);
          stage->setMonitoredStage(attach_stage_c1);

          auto wrapper = std::make_unique<mtc::stages::ComputeIK>("place buffer IK", std::move(stage));
          wrapper->setMaxIKSolutions(2);
          wrapper->setMinSolutionDistance(1.0);
          wrapper->setIKFrame("cylinder_1");
          wrapper->properties().configureInitFrom(mtc::Stage::PARENT, { "eef", "group" });
          wrapper->properties().configureInitFrom(mtc::Stage::INTERFACE, { "target_pose" });
          place->insert(std::move(wrapper));
      }
      {
          auto stage = std::make_unique<mtc::stages::MoveTo>("open hand buffer", interpolation_planner);
          stage->setGroup(hand_group_name);
          stage->setGoal("open");
          place->insert(std::move(stage));
      }
      {
          auto stage = std::make_unique<mtc::stages::ModifyPlanningScene>("detach C1");
          stage->detachObject("cylinder_1", hand_frame);
          place->insert(std::move(stage));
      }
      {
          auto stage = std::make_unique<mtc::stages::MoveRelative>("retreat buffer", cartesian_planner);
          stage->properties().configureInitFrom(mtc::Stage::PARENT, { "group" });
          stage->setMinMaxDistance(0.1, 0.3);
          stage->setIKFrame(hand_frame);
          geometry_msgs::msg::Vector3Stamped vec;
          vec.header.frame_id = "world";
          vec.vector.x = -0.5;
          stage->setDirection(vec);
          place->insert(std::move(stage));
      }
      
      task.add(std::move(place));
  }

  // 4. RETURN HOME
  {
      auto stage_home = std::make_unique<mtc::stages::MoveTo>("return home", interpolation_planner);
      stage_home->properties().configureInitFrom(mtc::Stage::PARENT, { "group" });
      stage_home->setGoal("ready");
      task.add(std::move(stage_home));
  }

  return task;
}

int main(int argc, char** argv)
{
  rclcpp::init(argc, argv);
  rclcpp::NodeOptions options;
  options.automatically_declare_parameters_from_overrides(true);

  auto mtc_task_node = std::make_shared<MTCTaskNode>(options);
  rclcpp::executors::MultiThreadedExecutor executor;

  auto spin_thread = std::make_unique<std::thread>([&executor, &mtc_task_node]() {
    executor.add_node(mtc_task_node->getNodeBaseInterface());
    executor.spin();
    executor.remove_node(mtc_task_node->getNodeBaseInterface());
  });

  mtc_task_node->setupPlanningScene();
  mtc_task_node->doTask();

  spin_thread->join();
  rclcpp::shutdown();
  return 0;
}