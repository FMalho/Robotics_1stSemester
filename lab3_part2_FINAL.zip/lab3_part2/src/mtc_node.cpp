#include <rclcpp/rclcpp.hpp>
#include <moveit/planning_scene/planning_scene.h>
#include <moveit/planning_scene_interface/planning_scene_interface.h>
#include <moveit/task_constructor/task.h>
#include <moveit/task_constructor/solvers.h>
#include <moveit/task_constructor/stages.h>
#include <geometry_msgs/msg/pose.hpp>
#include <moveit_msgs/msg/collision_object.hpp>
#include <shape_msgs/msg/solid_primitive.hpp>
#include <tf2_geometry_msgs/tf2_geometry_msgs.hpp>
#include <tf2_eigen/tf2_eigen.hpp>

static const rclcpp::Logger LOGGER = rclcpp::get_logger("mtc_tutorial");
namespace mtc = moveit::task_constructor;

class MTCTaskNode
{
public:
  MTCTaskNode(const rclcpp::NodeOptions& options);
  rclcpp::node_interfaces::NodeBaseInterface::SharedPtr getNodeBaseInterface();
  void doTask();
  void setupPlanningScene();

private:
  mtc::Task createTask();
  mtc::Task task_;
  rclcpp::Node::SharedPtr node_;
};

MTCTaskNode::MTCTaskNode(const rclcpp::NodeOptions& options)
  : node_{ std::make_shared<rclcpp::Node>("mtc_node", options) }
{
}

rclcpp::node_interfaces::NodeBaseInterface::SharedPtr MTCTaskNode::getNodeBaseInterface()
{
  return node_->get_node_base_interface();
}

void MTCTaskNode::setupPlanningScene()
{
  moveit::planning_interface::PlanningSceneInterface psi;

  // --- CILINDRO 1 (VERDE) ---
  moveit_msgs::msg::CollisionObject c1;
  c1.id = "cylinder_1";
  c1.header.frame_id = "world";
  c1.primitives.resize(1);
  c1.primitives[0].type = shape_msgs::msg::SolidPrimitive::CYLINDER;
  c1.primitives[0].dimensions = { 0.08, 0.015 }; 
  c1.pose.position.x = 0.15;  
  c1.pose.position.y = -0.12; 
  c1.pose.position.z = 0.04;  
  c1.pose.orientation.w = 1.0;

  moveit_msgs::msg::ObjectColor color1;
  color1.id = "cylinder_1";
  color1.color.r = 0.0; color1.color.g = 1.0; color1.color.b = 0.0; color1.color.a = 1.0;

  // --- CILINDRO 2 (AZUL) ---
  moveit_msgs::msg::CollisionObject c2;
  c2.id = "cylinder_2";
  c2.header.frame_id = "world";
  c2.primitives.resize(1);
  c2.primitives[0].type = shape_msgs::msg::SolidPrimitive::CYLINDER;
  c2.primitives[0].dimensions = { 0.08, 0.015 };
  c2.pose.position.x = -0.15;
  c2.pose.position.y = -0.12; 
  c2.pose.position.z = 0.04;
  c2.pose.orientation.w = 1.0;

  moveit_msgs::msg::ObjectColor color2;
  color2.id = "cylinder_2";
  color2.color.r = 0.0; color2.color.g = 0.0; color2.color.b = 1.0; color2.color.a = 1.0;

  psi.applyCollisionObject(c1, color1.color);
  psi.applyCollisionObject(c2, color2.color);
}

void MTCTaskNode::doTask()
{
  task_ = createTask();
  try {
    task_.init();
  } catch (mtc::InitStageException& e) {
    RCLCPP_ERROR_STREAM(LOGGER, e);
    return;
  }

  if (!task_.plan(10)) {
    RCLCPP_ERROR_STREAM(LOGGER, "Task planning failed");
    return;
  }
  task_.introspection().publishSolution(*task_.solutions().front());
  auto result = task_.execute(*task_.solutions().front());
  
  if (result.val != moveit_msgs::msg::MoveItErrorCodes::SUCCESS) {
    RCLCPP_ERROR_STREAM(LOGGER, "Task execution failed");
  }
}

mtc::Task MTCTaskNode::createTask()
{
  mtc::Task task;
  task.stages()->setName("Swap SO-ARM101");
  task.loadRobotModel(node_);

  const auto& arm_group_name = "arm";
  const auto& hand_group_name = "gripper";
  const auto& eef_name = "end_effector"; 
  const auto& hand_frame = "gripper"; 

  task.enableIntrospection(true);

  task.setProperty("group", arm_group_name);
  task.setProperty("eef", eef_name); 
  task.setProperty("ik_frame", hand_frame);

  auto sampling_planner = std::make_shared<mtc::solvers::PipelinePlanner>(node_, "ompl");
  auto interpolation_planner = std::make_shared<mtc::solvers::JointInterpolationPlanner>();
  auto cartesian_planner = std::make_shared<mtc::solvers::CartesianPath>();
  cartesian_planner->setMaxVelocityScalingFactor(0.5);
  cartesian_planner->setMaxAccelerationScalingFactor(0.5);
  cartesian_planner->setStepSize(0.01);

  mtc::Stage* current_state_ptr = nullptr;
  mtc::Stage* attach_stage_c1 = nullptr;
  mtc::Stage* attach_stage_c2 = nullptr;
  mtc::Stage* stage_after_place_buffer = nullptr;
  mtc::Stage* stage_after_place_c2 = nullptr;

  // --- POSIÇÕES ---
  geometry_msgs::msg::Pose pose_buffer;
  pose_buffer.position.x = 0.0; 
  pose_buffer.position.y = -0.15; 
  pose_buffer.position.z = 0.04;
  pose_buffer.orientation.w = 1.0;

  geometry_msgs::msg::Pose pose_final_c1;
  pose_final_c1.position.x = -0.15; 
  pose_final_c1.position.y = -0.12; 
  pose_final_c1.position.z = 0.04;
  pose_final_c1.orientation.w = 1.0;

  geometry_msgs::msg::Pose pose_final_c2;
  pose_final_c2.position.x = 0.15; 
  pose_final_c2.position.y = -0.12; 
  pose_final_c2.position.z = 0.04;
  pose_final_c2.orientation.w = 1.0;

  

  // =========================================================
  // 1. ESTADO INICIAL 
  // =========================================================
  {
      auto stage_state_current = std::make_unique<mtc::stages::CurrentState>("current");
      current_state_ptr = stage_state_current.get();
      task.add(std::move(stage_state_current));

      // A. DESLIGAR COLISÕES NO INÍCIO
      {
          auto stage = std::make_unique<mtc::stages::ModifyPlanningScene>("ignore all collisions");
          std::vector<std::string> robot_links = { "base", "shoulder", "upper_arm", "lower_arm", "wrist", "gripper", "jaw" };
          for(const auto& link : robot_links) { stage->allowCollisions(link, true); }
          stage->allowCollisions("cylinder_1", true);
          stage->allowCollisions("cylinder_2", true);
          task.add(std::move(stage));
      }

      auto stage_open_hand = std::make_unique<mtc::stages::MoveTo>("open hand", interpolation_planner);
      stage_open_hand->setGroup(hand_group_name);
      stage_open_hand->setGoal("open");
      task.add(std::move(stage_open_hand));

      // B. MOVER PARA READY (Pose Dobrada)
      {
          auto stage = std::make_unique<mtc::stages::MoveTo>("move to ready", sampling_planner);
          stage->setGroup(arm_group_name);
          std::map<std::string, double> ready_pose;
          ready_pose["Rotation"] = 0.0;
          ready_pose["Pitch"] = -0.5;   
          ready_pose["Elbow"] = 1.0;    
          ready_pose["Wrist_Pitch"] = 0.5; 
          ready_pose["Wrist_Roll"] = 0.0;
          stage->setGoal(ready_pose);
          task.add(std::move(stage));
      }

      // C. REATIVAR APENAS OBJETOS
      {
          auto stage = std::make_unique<mtc::stages::ModifyPlanningScene>("re-enable object collisions");
          stage->allowCollisions("cylinder_1", false);
          stage->allowCollisions("cylinder_2", false);
          task.add(std::move(stage));
      }
  }

  // ---------------------------------------------------------
  // 2. PICK CILINDRO 1 (FRENTE)
  // ---------------------------------------------------------
  {
      auto stage_connect = std::make_unique<mtc::stages::Connect>(
          "move to pick C1", mtc::stages::Connect::GroupPlannerVector{ { arm_group_name, sampling_planner } });
      stage_connect->setTimeout(10.0);
      stage_connect->properties().configureInitFrom(mtc::Stage::PARENT);
      task.add(std::move(stage_connect));

      auto grasp = std::make_unique<mtc::SerialContainer>("pick C1");
      task.properties().exposeTo(grasp->properties(), { "eef", "group", "ik_frame" });
      grasp->properties().configureInitFrom(mtc::Stage::PARENT, { "eef", "group", "ik_frame" });

      {
          auto stage = std::make_unique<mtc::stages::MoveRelative>("approach C1", cartesian_planner);
          stage->properties().set("marker_ns", "approach_c1");
          stage->properties().set("link", hand_frame);
          stage->properties().configureInitFrom(mtc::Stage::PARENT, { "group" });
          stage->setMinMaxDistance(0.01, 0.05); 
          geometry_msgs::msg::Vector3Stamped vec;
          vec.header.frame_id = hand_frame;
          vec.vector.x = 1.0; 
          stage->setDirection(vec);
          grasp->insert(std::move(stage));
      }
      {
          auto stage = std::make_unique<mtc::stages::GenerateGraspPose>("gen grasp C1");
          stage->properties().configureInitFrom(mtc::Stage::PARENT);
          stage->setPreGraspPose("open");
          stage->setObject("cylinder_1");
          stage->setAngleDelta(M_PI / 12);
          stage->setMonitoredStage(current_state_ptr);

          Eigen::Isometry3d grasp_frame_transform;
          Eigen::Quaterniond q = Eigen::AngleAxisd(0.0, Eigen::Vector3d::UnitY()) * Eigen::AngleAxisd(0.0, Eigen::Vector3d::UnitX());
          grasp_frame_transform.linear() = q.matrix();
          
          grasp_frame_transform.translation().x() = 0.01;
          grasp_frame_transform.translation().z() = -0.09;

          auto wrapper = std::make_unique<mtc::stages::ComputeIK>("grasp IK C1", std::move(stage));
          wrapper->setMaxIKSolutions(20);
          wrapper->setMinSolutionDistance(1.0);
          wrapper->setIKFrame(grasp_frame_transform, hand_frame);
          wrapper->properties().configureInitFrom(mtc::Stage::PARENT, { "eef", "group" });
          wrapper->properties().configureInitFrom(mtc::Stage::INTERFACE, { "target_pose" });
          grasp->insert(std::move(wrapper));
      }
      {
          auto stage = std::make_unique<mtc::stages::ModifyPlanningScene>("allow C1 collision");
          stage->allowCollisions("cylinder_1", task.getRobotModel()->getJointModelGroup(hand_group_name)->getLinkModelNamesWithCollisionGeometry(), true);
          grasp->insert(std::move(stage));
      }
      {
          auto stage = std::make_unique<mtc::stages::MoveTo>("close hand", interpolation_planner);
          stage->setGroup(hand_group_name);
          stage->setGoal("close");
          grasp->insert(std::move(stage));
      }
      {
          auto stage = std::make_unique<mtc::stages::ModifyPlanningScene>("attach C1");
          stage->attachObject("cylinder_1", hand_frame);
          attach_stage_c1 = stage.get();
          grasp->insert(std::move(stage));
      }
      {
          auto stage = std::make_unique<mtc::stages::MoveRelative>("lift C1", cartesian_planner);
          stage->properties().configureInitFrom(mtc::Stage::PARENT, { "group" });
          stage->setMinMaxDistance(0.01, 0.05);
          stage->setIKFrame(hand_frame);
          geometry_msgs::msg::Vector3Stamped vec;
          vec.header.frame_id = "world";
          vec.vector.z = 1.0;
          stage->setDirection(vec);
          grasp->insert(std::move(stage));
      }
      task.add(std::move(grasp));
  }

  // ---------------------------------------------------------
  // 3. PLACE CILINDRO 1 (BUFFER - DIREITA)
  // ---------------------------------------------------------
  {
      auto stage_connect = std::make_unique<mtc::stages::Connect>(
          "move to buffer", mtc::stages::Connect::GroupPlannerVector{ { arm_group_name, sampling_planner } });
      stage_connect->setTimeout(10.0);
      stage_connect->properties().configureInitFrom(mtc::Stage::PARENT);
      task.add(std::move(stage_connect));

      auto place = std::make_unique<mtc::SerialContainer>("place C1 at Buffer");
      task.properties().exposeTo(place->properties(), { "eef", "group", "ik_frame" });
      place->properties().configureInitFrom(mtc::Stage::PARENT, { "eef", "group", "ik_frame" });

      {
          auto stage = std::make_unique<mtc::stages::GeneratePlacePose>("gen place buffer");
          stage->properties().configureInitFrom(mtc::Stage::PARENT);
          stage->setObject("cylinder_1");
          geometry_msgs::msg::PoseStamped target_pose_msg;
          target_pose_msg.header.frame_id = "world";
          target_pose_msg.pose = pose_buffer;
          stage->setPose(target_pose_msg);
          stage->setMonitoredStage(attach_stage_c1);

          auto wrapper = std::make_unique<mtc::stages::ComputeIK>("place buffer IK", std::move(stage));
          wrapper->setMaxIKSolutions(20);
          wrapper->setMinSolutionDistance(1.0);
          wrapper->setIKFrame("cylinder_1");
          wrapper->properties().configureInitFrom(mtc::Stage::PARENT, { "eef", "group" });
          wrapper->properties().configureInitFrom(mtc::Stage::INTERFACE, { "target_pose" });
          place->insert(std::move(wrapper));
      }
      {
          auto stage = std::make_unique<mtc::stages::MoveTo>("open hand buffer", interpolation_planner);
          stage->setGroup(hand_group_name);
          stage->setGoal("open");
          place->insert(std::move(stage));
      }
      {
          auto stage = std::make_unique<mtc::stages::ModifyPlanningScene>("detach C1");
          stage->detachObject("cylinder_1", hand_frame);
          place->insert(std::move(stage));
      }
      {
          auto stage = std::make_unique<mtc::stages::MoveRelative>("retreat buffer", cartesian_planner);
          stage->properties().configureInitFrom(mtc::Stage::PARENT, { "group" });
          stage->setMinMaxDistance(0.01, 0.05);
          stage->setIKFrame(hand_frame);
          geometry_msgs::msg::Vector3Stamped vec;
          vec.header.frame_id = "world";
          vec.vector.x = -0.5; 
          stage->setDirection(vec);
          place->insert(std::move(stage));
      }
      
      stage_after_place_buffer = place.get();
      task.add(std::move(place));
  }

  // ---------------------------------------------------------
  // 4. PICK CILINDRO 2 (ESQUERDA)
  // ---------------------------------------------------------
  {
      auto stage_connect = std::make_unique<mtc::stages::Connect>(
          "move to pick C2", mtc::stages::Connect::GroupPlannerVector{ { arm_group_name, sampling_planner } });
      stage_connect->setTimeout(10.0);
      stage_connect->properties().configureInitFrom(mtc::Stage::PARENT);
      task.add(std::move(stage_connect));

      auto grasp = std::make_unique<mtc::SerialContainer>("pick C2");
      task.properties().exposeTo(grasp->properties(), { "eef", "group", "ik_frame" });
      grasp->properties().configureInitFrom(mtc::Stage::PARENT, { "eef", "group", "ik_frame" });

      {
          auto stage = std::make_unique<mtc::stages::MoveRelative>("approach C2", cartesian_planner);
          stage->properties().set("marker_ns", "approach_c2");
          stage->properties().set("link", hand_frame);
          stage->properties().configureInitFrom(mtc::Stage::PARENT, { "group" });
          stage->setMinMaxDistance(0.01, 0.05);
          geometry_msgs::msg::Vector3Stamped vec;
          vec.header.frame_id = hand_frame;
          vec.vector.x = 1.0;
          stage->setDirection(vec);
          grasp->insert(std::move(stage));
      }
      {
          auto stage = std::make_unique<mtc::stages::GenerateGraspPose>("gen grasp C2");
          stage->properties().configureInitFrom(mtc::Stage::PARENT);
          stage->setPreGraspPose("open");
          stage->setObject("cylinder_2");
          stage->setAngleDelta(M_PI / 12);
          
          stage->setMonitoredStage(stage_after_place_buffer);

          Eigen::Isometry3d grasp_frame_transform;
          Eigen::Quaterniond q = Eigen::AngleAxisd(0.0, Eigen::Vector3d::UnitY()) * Eigen::AngleAxisd(0.0, Eigen::Vector3d::UnitX());
          grasp_frame_transform.linear() = q.matrix();
          
          grasp_frame_transform.translation().x() = 0.01;
          grasp_frame_transform.translation().z() = -0.09;

          auto wrapper = std::make_unique<mtc::stages::ComputeIK>("grasp IK C2", std::move(stage));
          wrapper->setMaxIKSolutions(20);
          wrapper->setMinSolutionDistance(1.0);
          wrapper->setIKFrame(grasp_frame_transform, hand_frame);
          wrapper->properties().configureInitFrom(mtc::Stage::PARENT, { "eef", "group" });
          wrapper->properties().configureInitFrom(mtc::Stage::INTERFACE, { "target_pose" });
          grasp->insert(std::move(wrapper));
      }
      {
          auto stage = std::make_unique<mtc::stages::ModifyPlanningScene>("allow C2 collision");
          stage->allowCollisions("cylinder_2", task.getRobotModel()->getJointModelGroup(hand_group_name)->getLinkModelNamesWithCollisionGeometry(), true);
          grasp->insert(std::move(stage));
      }
      {
          auto stage = std::make_unique<mtc::stages::MoveTo>("close hand C2", interpolation_planner);
          stage->setGroup(hand_group_name);
          stage->setGoal("close");
          grasp->insert(std::move(stage));
      }
      {
          auto stage = std::make_unique<mtc::stages::ModifyPlanningScene>("attach C2");
          stage->attachObject("cylinder_2", hand_frame);
          attach_stage_c2 = stage.get();
          grasp->insert(std::move(stage));
      }
      {
          auto stage = std::make_unique<mtc::stages::MoveRelative>("lift C2", cartesian_planner);
          stage->properties().configureInitFrom(mtc::Stage::PARENT, { "group" });
          stage->setMinMaxDistance(0.01, 0.05);
          stage->setIKFrame(hand_frame);
          geometry_msgs::msg::Vector3Stamped vec;
          vec.header.frame_id = "world";
          vec.vector.z = 1.0;
          stage->setDirection(vec);
          grasp->insert(std::move(stage));
      }
      task.add(std::move(grasp));
  }

  // ---------------------------------------------------------
  // 5. PLACE CILINDRO 2 (POSIÇÃO A - Onde estava o C1)
  // ---------------------------------------------------------
  {
      auto stage_connect = std::make_unique<mtc::stages::Connect>(
          "move to place C2", mtc::stages::Connect::GroupPlannerVector{ { arm_group_name, sampling_planner } });
      stage_connect->setTimeout(10.0);
      stage_connect->properties().configureInitFrom(mtc::Stage::PARENT);
      task.add(std::move(stage_connect));

      auto place = std::make_unique<mtc::SerialContainer>("place C2 at PosA");
      task.properties().exposeTo(place->properties(), { "eef", "group", "ik_frame" });
      place->properties().configureInitFrom(mtc::Stage::PARENT, { "eef", "group", "ik_frame" });

      {
          auto stage = std::make_unique<mtc::stages::GeneratePlacePose>("gen place C2");
          stage->properties().configureInitFrom(mtc::Stage::PARENT);
          stage->setObject("cylinder_2");
          geometry_msgs::msg::PoseStamped target_pose_msg;
          target_pose_msg.header.frame_id = "world";
          target_pose_msg.pose = pose_final_c2; 
          stage->setPose(target_pose_msg);
          stage->setMonitoredStage(attach_stage_c2);

          auto wrapper = std::make_unique<mtc::stages::ComputeIK>("place C2 IK", std::move(stage));
          wrapper->setMaxIKSolutions(20);
          wrapper->setMinSolutionDistance(1.0);
          wrapper->setIKFrame("cylinder_2");
          wrapper->properties().configureInitFrom(mtc::Stage::PARENT, { "eef", "group" });
          wrapper->properties().configureInitFrom(mtc::Stage::INTERFACE, { "target_pose" });
          place->insert(std::move(wrapper));
      }
      {
          auto stage = std::make_unique<mtc::stages::MoveTo>("open hand C2", interpolation_planner);
          stage->setGroup(hand_group_name);
          stage->setGoal("open");
          place->insert(std::move(stage));
      }
      {
          auto stage = std::make_unique<mtc::stages::ModifyPlanningScene>("detach C2");
          stage->detachObject("cylinder_2", hand_frame);
          place->insert(std::move(stage));
      }
      {
          auto stage = std::make_unique<mtc::stages::MoveRelative>("retreat C2", cartesian_planner);
          stage->properties().configureInitFrom(mtc::Stage::PARENT, { "group" });
          stage->setMinMaxDistance(0.01, 0.05);
          stage->setIKFrame(hand_frame);
          geometry_msgs::msg::Vector3Stamped vec;
          vec.header.frame_id = "world";
          vec.vector.x = -0.5;
          stage->setDirection(vec);
          place->insert(std::move(stage));
      }
      
      stage_after_place_c2 = place.get();
      task.add(std::move(place));
  }

  // ---------------------------------------------------------
  // 6. PICK CILINDRO 1 (BUFFER)
  // ---------------------------------------------------------
  {
      auto stage_connect = std::make_unique<mtc::stages::Connect>(
          "move to pick C1 Buf", mtc::stages::Connect::GroupPlannerVector{ { arm_group_name, sampling_planner } });
      stage_connect->setTimeout(10.0);
      stage_connect->properties().configureInitFrom(mtc::Stage::PARENT);
      task.add(std::move(stage_connect));

      auto grasp = std::make_unique<mtc::SerialContainer>("pick C1 from Buffer");
      task.properties().exposeTo(grasp->properties(), { "eef", "group", "ik_frame" });
      grasp->properties().configureInitFrom(mtc::Stage::PARENT, { "eef", "group", "ik_frame" });

      {
          auto stage = std::make_unique<mtc::stages::MoveRelative>("approach C1 Buf", cartesian_planner);
          stage->properties().set("marker_ns", "approach_c1_buf");
          stage->properties().set("link", hand_frame);
          stage->properties().configureInitFrom(mtc::Stage::PARENT, { "group" });
          stage->setMinMaxDistance(0.01, 0.05);
          geometry_msgs::msg::Vector3Stamped vec;
          vec.header.frame_id = hand_frame;
          vec.vector.x = 1.0;
          stage->setDirection(vec);
          grasp->insert(std::move(stage));
      }
      {
          auto stage = std::make_unique<mtc::stages::GenerateGraspPose>("gen grasp C1 Buf");
          stage->properties().configureInitFrom(mtc::Stage::PARENT);
          stage->setPreGraspPose("open");
          stage->setObject("cylinder_1");
          stage->setAngleDelta(M_PI / 12);
          
          stage->setMonitoredStage(stage_after_place_c2); 

          Eigen::Isometry3d grasp_frame_transform;
          Eigen::Quaterniond q = Eigen::AngleAxisd(0.0, Eigen::Vector3d::UnitY()) * Eigen::AngleAxisd(0.0, Eigen::Vector3d::UnitX());
          grasp_frame_transform.linear() = q.matrix();
          
          grasp_frame_transform.translation().x() = 0.01;
          grasp_frame_transform.translation().z() = -0.09;

          auto wrapper = std::make_unique<mtc::stages::ComputeIK>("grasp IK C1 Buf", std::move(stage));
          wrapper->setMaxIKSolutions(20);
          wrapper->setMinSolutionDistance(1.0);
          wrapper->setIKFrame(grasp_frame_transform, hand_frame);
          wrapper->properties().configureInitFrom(mtc::Stage::PARENT, { "eef", "group" });
          wrapper->properties().configureInitFrom(mtc::Stage::INTERFACE, { "target_pose" });
          grasp->insert(std::move(wrapper));
      }
      {
          auto stage = std::make_unique<mtc::stages::ModifyPlanningScene>("allow collision C1 Buf");
          stage->allowCollisions("cylinder_1", task.getRobotModel()->getJointModelGroup(hand_group_name)->getLinkModelNamesWithCollisionGeometry(), true);
          grasp->insert(std::move(stage));
      }
      {
          auto stage = std::make_unique<mtc::stages::MoveTo>("close hand C1 Buf", interpolation_planner);
          stage->setGroup(hand_group_name);
          stage->setGoal("close");
          grasp->insert(std::move(stage));
      }
      {
          auto stage = std::make_unique<mtc::stages::ModifyPlanningScene>("attach C1 Buf");
          stage->attachObject("cylinder_1", hand_frame);
          attach_stage_c1 = stage.get(); 
          grasp->insert(std::move(stage));
      }
      {
          auto stage = std::make_unique<mtc::stages::MoveRelative>("lift C1 Buf", cartesian_planner);
          stage->properties().configureInitFrom(mtc::Stage::PARENT, { "group" });
          stage->setMinMaxDistance(0.01, 0.05);
          stage->setIKFrame(hand_frame);
          geometry_msgs::msg::Vector3Stamped vec;
          vec.header.frame_id = "world";
          vec.vector.z = 1.0;
          stage->setDirection(vec);
          grasp->insert(std::move(stage));
      }
      task.add(std::move(grasp));
  }

  // ---------------------------------------------------------
  // 7. PLACE CILINDRO 1 (POSIÇÃO FINAL - ESQUERDA)
  // ---------------------------------------------------------
  {
      auto stage_connect = std::make_unique<mtc::stages::Connect>(
          "move to place C1 final", mtc::stages::Connect::GroupPlannerVector{ { arm_group_name, sampling_planner } });
      stage_connect->setTimeout(10.0);
      stage_connect->properties().configureInitFrom(mtc::Stage::PARENT);
      task.add(std::move(stage_connect));

      auto place = std::make_unique<mtc::SerialContainer>("place C1 at PosB");
      task.properties().exposeTo(place->properties(), { "eef", "group", "ik_frame" });
      place->properties().configureInitFrom(mtc::Stage::PARENT, { "eef", "group", "ik_frame" });

      {
          auto stage = std::make_unique<mtc::stages::GeneratePlacePose>("gen place C1 final");
          stage->properties().configureInitFrom(mtc::Stage::PARENT);
          stage->setObject("cylinder_1");
          geometry_msgs::msg::PoseStamped target_pose_msg;
          target_pose_msg.header.frame_id = "world";
          target_pose_msg.pose = pose_final_c1; 
          stage->setPose(target_pose_msg);
          stage->setMonitoredStage(attach_stage_c1); 

          auto wrapper = std::make_unique<mtc::stages::ComputeIK>("place C1 Final IK", std::move(stage));
          wrapper->setMaxIKSolutions(20);
          wrapper->setMinSolutionDistance(1.0);
          wrapper->setIKFrame("cylinder_1");
          wrapper->properties().configureInitFrom(mtc::Stage::PARENT, { "eef", "group" });
          wrapper->properties().configureInitFrom(mtc::Stage::INTERFACE, { "target_pose" });
          place->insert(std::move(wrapper));
      }
      {
          auto stage = std::make_unique<mtc::stages::MoveTo>("open hand final", interpolation_planner);
          stage->setGroup(hand_group_name);
          stage->setGoal("open");
          place->insert(std::move(stage));
      }
      {
          auto stage = std::make_unique<mtc::stages::ModifyPlanningScene>("detach C1 final");
          stage->detachObject("cylinder_1", hand_frame);
          place->insert(std::move(stage));
      }
      {
          auto stage = std::make_unique<mtc::stages::MoveRelative>("retreat final", cartesian_planner);
          stage->properties().configureInitFrom(mtc::Stage::PARENT, { "group" });
          stage->setMinMaxDistance(0.01, 0.05);
          stage->setIKFrame(hand_frame);
          geometry_msgs::msg::Vector3Stamped vec;
          vec.header.frame_id = "world";
          vec.vector.x = -0.5;
          stage->setDirection(vec);
          place->insert(std::move(stage));
      }
      task.add(std::move(place));
  }

  // ---------------------------------------------------------
  // 8. RETURN HOME
  // ---------------------------------------------------------
  {
      auto stage_home = std::make_unique<mtc::stages::MoveTo>("return home", interpolation_planner);
      stage_home->properties().configureInitFrom(mtc::Stage::PARENT, { "group" });
      
      std::map<std::string, double> ready_pose;
      ready_pose["Rotation"] = 0.0;
      ready_pose["Pitch"] = -0.5;
      ready_pose["Elbow"] = 1.0;
      ready_pose["Wrist_Pitch"] = 0.5;
      ready_pose["Wrist_Roll"] = 0.0;
      stage_home->setGoal(ready_pose);
      
      task.add(std::move(stage_home));
  }

  return task;
}

int main(int argc, char** argv)
{
  rclcpp::init(argc, argv);
  rclcpp::NodeOptions options;
  options.automatically_declare_parameters_from_overrides(true);

  auto mtc_task_node = std::make_shared<MTCTaskNode>(options);
  rclcpp::executors::MultiThreadedExecutor executor;

  auto spin_thread = std::make_unique<std::thread>([&executor, &mtc_task_node]() {
    executor.add_node(mtc_task_node->getNodeBaseInterface());
    executor.spin();
    executor.remove_node(mtc_task_node->getNodeBaseInterface());
  });

  mtc_task_node->setupPlanningScene();
  mtc_task_node->doTask();

  spin_thread->join();
  rclcpp::shutdown();
  return 0;
}