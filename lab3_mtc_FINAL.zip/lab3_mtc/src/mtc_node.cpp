#include <rclcpp/rclcpp.hpp>
#include <moveit/planning_scene/planning_scene.h>
#include <moveit/planning_scene_interface/planning_scene_interface.h>
#include <moveit/task_constructor/task.h>
#include <moveit/task_constructor/solvers.h>
#include <moveit/task_constructor/stages.h>
#include <geometry_msgs/msg/pose.hpp>
#include <moveit_msgs/msg/collision_object.hpp>
#include <shape_msgs/msg/solid_primitive.hpp>
#include <tf2_geometry_msgs/tf2_geometry_msgs.hpp>
#include <tf2_eigen/tf2_eigen.hpp>

static const rclcpp::Logger LOGGER = rclcpp::get_logger("simple_mtc");
namespace mtc = moveit::task_constructor;

class SimplePickPlaceNode
{
public:
  SimplePickPlaceNode(const rclcpp::NodeOptions& options);
  rclcpp::node_interfaces::NodeBaseInterface::SharedPtr getNodeBaseInterface();
  void doTask();
  void setupPlanningScene();

private:
  mtc::Task createTask();
  mtc::Task task_;
  rclcpp::Node::SharedPtr node_;
};

SimplePickPlaceNode::SimplePickPlaceNode(const rclcpp::NodeOptions& options)
  : node_{ std::make_shared<rclcpp::Node>("mtc_node", options) }
{
}

rclcpp::node_interfaces::NodeBaseInterface::SharedPtr SimplePickPlaceNode::getNodeBaseInterface()
{
  return node_->get_node_base_interface();
}

void SimplePickPlaceNode::setupPlanningScene()
{
  moveit::planning_interface::PlanningSceneInterface psi;

  // --- CILINDRO 1 (VERDE) APENAS ---
  moveit_msgs::msg::CollisionObject c1;
  c1.id = "cylinder_1";
  c1.header.frame_id = "world";
  c1.primitives.resize(1);
  c1.primitives[0].type = shape_msgs::msg::SolidPrimitive::CYLINDER;
  c1.primitives[0].dimensions = { 0.08, 0.015 }; 
  // Posição Inicial (Pick)
  c1.pose.position.x = 0.15;  
  c1.pose.position.y = -0.12; 
  c1.pose.position.z = 0.04;  
  c1.pose.orientation.w = 1.0;

  moveit_msgs::msg::ObjectColor color1;
  color1.id = "cylinder_1";
  color1.color.r = 0.0; color1.color.g = 1.0; color1.color.b = 0.0; color1.color.a = 1.0;

  psi.applyCollisionObject(c1, color1.color);
}

void SimplePickPlaceNode::doTask()
{
  task_ = createTask();
  try {
    task_.init();
  } catch (mtc::InitStageException& e) {
    RCLCPP_ERROR_STREAM(LOGGER, e);
    return;
  }

  if (!task_.plan(10)) {
    RCLCPP_ERROR_STREAM(LOGGER, "Task planning failed");
    return;
  }
  task_.introspection().publishSolution(*task_.solutions().front());
  auto result = task_.execute(*task_.solutions().front());
  
  if (result.val != moveit_msgs::msg::MoveItErrorCodes::SUCCESS) {
    RCLCPP_ERROR_STREAM(LOGGER, "Task execution failed");
  }
}

mtc::Task SimplePickPlaceNode::createTask()
{
  mtc::Task task;
  task.stages()->setName("Simple Pick & Place");
  task.loadRobotModel(node_);

  const auto& arm_group_name = "arm";
  const auto& hand_group_name = "gripper";
  const auto& eef_name = "end_effector"; 
  const auto& hand_frame = "gripper"; 

  task.enableIntrospection(true);

  task.setProperty("group", arm_group_name);
  task.setProperty("eef", eef_name); 
  task.setProperty("ik_frame", hand_frame);

  auto sampling_planner = std::make_shared<mtc::solvers::PipelinePlanner>(node_, "ompl");
  auto interpolation_planner = std::make_shared<mtc::solvers::JointInterpolationPlanner>();
  auto cartesian_planner = std::make_shared<mtc::solvers::CartesianPath>();
  cartesian_planner->setMaxVelocityScalingFactor(0.5);
  cartesian_planner->setMaxAccelerationScalingFactor(0.5);
  cartesian_planner->setStepSize(0.01);

  mtc::Stage* attach_stage_c1 = nullptr;

  // --- POSIÇÃO FINAL (PLACE) ---
  geometry_msgs::msg::Pose pose_place;
  pose_place.position.x = -0.15; 
  pose_place.position.y = -0.12; 
  pose_place.position.z = 0.04;
  pose_place.orientation.w = 1.0;

  // 1. ESTADO INICIAL 
  {
      auto stage_state_current = std::make_unique<mtc::stages::CurrentState>("current");
      task.add(std::move(stage_state_current));

      auto stage_open_hand = std::make_unique<mtc::stages::MoveTo>("open hand", interpolation_planner);
      stage_open_hand->setGroup(hand_group_name);
      stage_open_hand->setGoal("open");
      task.add(std::move(stage_open_hand));

      auto stage_ready = std::make_unique<mtc::stages::MoveTo>("move to ready", sampling_planner);
      stage_ready->setGroup(arm_group_name);
      std::map<std::string, double> ready_pose;
      ready_pose["Rotation"] = 0.0;
      ready_pose["Pitch"] = -0.5;   
      ready_pose["Elbow"] = 1.0;    
      ready_pose["Wrist_Pitch"] = 0.5; 
      ready_pose["Wrist_Roll"] = 0.0;
      stage_ready->setGoal(ready_pose);
      task.add(std::move(stage_ready));
  }

  // 2. PICK CILINDRO 1
  {
      auto stage_connect = std::make_unique<mtc::stages::Connect>(
          "move to pick", mtc::stages::Connect::GroupPlannerVector{ { arm_group_name, sampling_planner } });
      stage_connect->setTimeout(10.0);
      stage_connect->properties().configureInitFrom(mtc::Stage::PARENT);
      task.add(std::move(stage_connect));

      auto grasp = std::make_unique<mtc::SerialContainer>("pick object");
      task.properties().exposeTo(grasp->properties(), { "eef", "group", "ik_frame" });
      grasp->properties().configureInitFrom(mtc::Stage::PARENT, { "eef", "group", "ik_frame" });

      {
          auto stage = std::make_unique<mtc::stages::MoveRelative>("approach object", cartesian_planner);
          stage->properties().set("marker_ns", "approach_object");
          stage->properties().set("link", hand_frame);
          stage->properties().configureInitFrom(mtc::Stage::PARENT, { "group" });
          stage->setMinMaxDistance(0.01, 0.05); 
          geometry_msgs::msg::Vector3Stamped vec;
          vec.header.frame_id = hand_frame;
          vec.vector.x = 1.0; 
          stage->setDirection(vec);
          grasp->insert(std::move(stage));
      }
      {
          auto stage = std::make_unique<mtc::stages::GenerateGraspPose>("generate grasp pose");
          stage->properties().configureInitFrom(mtc::Stage::PARENT);
          stage->setPreGraspPose("open");
          stage->setObject("cylinder_1");
          stage->setAngleDelta(M_PI / 12);
          stage->setMonitoredStage(task.stages()->findChild("current"));

          Eigen::Isometry3d grasp_frame_transform;
          Eigen::Quaterniond q = Eigen::AngleAxisd(0.0, Eigen::Vector3d::UnitY()) * Eigen::AngleAxisd(0.0, Eigen::Vector3d::UnitX());
          grasp_frame_transform.linear() = q.matrix();
          grasp_frame_transform.translation().x() = 0.01;
          grasp_frame_transform.translation().z() = -0.09;

          auto wrapper = std::make_unique<mtc::stages::ComputeIK>("grasp IK", std::move(stage));
          wrapper->setMaxIKSolutions(20);
          wrapper->setMinSolutionDistance(1.0);
          wrapper->setIKFrame(grasp_frame_transform, hand_frame);
          wrapper->properties().configureInitFrom(mtc::Stage::PARENT, { "eef", "group" });
          wrapper->properties().configureInitFrom(mtc::Stage::INTERFACE, { "target_pose" });
          grasp->insert(std::move(wrapper));
      }
      {
          auto stage = std::make_unique<mtc::stages::ModifyPlanningScene>("allow collision");
          stage->allowCollisions("cylinder_1", task.getRobotModel()->getJointModelGroup(hand_group_name)->getLinkModelNamesWithCollisionGeometry(), true);
          grasp->insert(std::move(stage));
      }
      {
          auto stage = std::make_unique<mtc::stages::MoveTo>("close hand", interpolation_planner);
          stage->setGroup(hand_group_name);
          stage->setGoal("close");
          grasp->insert(std::move(stage));
      }
      {
          auto stage = std::make_unique<mtc::stages::ModifyPlanningScene>("attach object");
          stage->attachObject("cylinder_1", hand_frame);
          attach_stage_c1 = stage.get();
          grasp->insert(std::move(stage));
      }
      {
          auto stage = std::make_unique<mtc::stages::MoveRelative>("lift object", cartesian_planner);
          stage->properties().configureInitFrom(mtc::Stage::PARENT, { "group" });
          stage->setMinMaxDistance(0.01, 0.05);
          stage->setIKFrame(hand_frame);
          geometry_msgs::msg::Vector3Stamped vec;
          vec.header.frame_id = "world";
          vec.vector.z = 1.0;
          stage->setDirection(vec);
          grasp->insert(std::move(stage));
      }
      task.add(std::move(grasp));
  }

  // 3. PLACE CILINDRO 1
  {
      auto stage_connect = std::make_unique<mtc::stages::Connect>(
          "move to place", mtc::stages::Connect::GroupPlannerVector{ { arm_group_name, sampling_planner } });
      stage_connect->setTimeout(10.0);
      stage_connect->properties().configureInitFrom(mtc::Stage::PARENT);
      task.add(std::move(stage_connect));

      auto place = std::make_unique<mtc::SerialContainer>("place object");
      task.properties().exposeTo(place->properties(), { "eef", "group", "ik_frame" });
      place->properties().configureInitFrom(mtc::Stage::PARENT, { "eef", "group", "ik_frame" });

      {
          auto stage = std::make_unique<mtc::stages::GeneratePlacePose>("generate place pose");
          stage->properties().configureInitFrom(mtc::Stage::PARENT);
          stage->setObject("cylinder_1");
          geometry_msgs::msg::PoseStamped target_pose_msg;
          target_pose_msg.header.frame_id = "world";
          target_pose_msg.pose = pose_place;
          stage->setPose(target_pose_msg);
          stage->setMonitoredStage(attach_stage_c1);

          auto wrapper = std::make_unique<mtc::stages::ComputeIK>("place IK", std::move(stage));
          wrapper->setMaxIKSolutions(20);
          wrapper->setMinSolutionDistance(1.0);
          wrapper->setIKFrame("cylinder_1");
          wrapper->properties().configureInitFrom(mtc::Stage::PARENT, { "eef", "group" });
          wrapper->properties().configureInitFrom(mtc::Stage::INTERFACE, { "target_pose" });
          place->insert(std::move(wrapper));
      }
      {
          auto stage = std::make_unique<mtc::stages::MoveTo>("open hand", interpolation_planner);
          stage->setGroup(hand_group_name);
          stage->setGoal("open");
          place->insert(std::move(stage));
      }
      {
          auto stage = std::make_unique<mtc::stages::ModifyPlanningScene>("detach object");
          stage->detachObject("cylinder_1", hand_frame);
          place->insert(std::move(stage));
      }
      {
          auto stage = std::make_unique<mtc::stages::MoveRelative>("retreat", cartesian_planner);
          stage->properties().configureInitFrom(mtc::Stage::PARENT, { "group" });
          stage->setMinMaxDistance(0.01, 0.05);
          stage->setIKFrame(hand_frame);
          geometry_msgs::msg::Vector3Stamped vec;
          vec.header.frame_id = "world";
          vec.vector.x = -0.5; 
          stage->setDirection(vec);
          place->insert(std::move(stage));
      }
      
      task.add(std::move(place));
  }

  // 4. RETURN HOME
  {
      auto stage_home = std::make_unique<mtc::stages::MoveTo>("return home", interpolation_planner);
      stage_home->properties().configureInitFrom(mtc::Stage::PARENT, { "group" });
      
      std::map<std::string, double> ready_pose;
      ready_pose["Rotation"] = 0.0;
      ready_pose["Pitch"] = -0.5;
      ready_pose["Elbow"] = 1.0;
      ready_pose["Wrist_Pitch"] = 0.5;
      ready_pose["Wrist_Roll"] = 0.0;
      stage_home->setGoal(ready_pose);
      
      task.add(std::move(stage_home));
  }

  return task;
}

int main(int argc, char** argv)
{
  rclcpp::init(argc, argv);
  rclcpp::NodeOptions options;
  options.automatically_declare_parameters_from_overrides(true);

  auto node = std::make_shared<SimplePickPlaceNode>(options);
  rclcpp::executors::MultiThreadedExecutor executor;

  auto spin_thread = std::make_unique<std::thread>([&executor, &node]() {
    executor.add_node(node->getNodeBaseInterface());
    executor.spin();
    executor.remove_node(node->getNodeBaseInterface());
  });

  node->setupPlanningScene();
  node->doTask();

  spin_thread->join();
  rclcpp::shutdown();
  return 0;
}